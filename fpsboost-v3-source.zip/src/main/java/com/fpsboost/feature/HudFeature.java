package com.fpsboost.feature;

import com.fpsboost.FpsBoostConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/** Ekranda gorunen modul. Konumu HUD duzenleyicide surukleyerek degistirilir. */
public abstract class HudFeature extends Feature {
    public final Setting scale;
    public final Setting background;

    /** Son cizimdeki ekran sinirlari (HUD duzenleyici icin). */
    public int bx;
    public int by;
    public int bw;
    public int bh;

    private final int dx;
    private final int dy;
    private final boolean right;
    private final boolean bottom;

    protected HudFeature(String id, String name, String description, boolean defaultEnabled, boolean backgroundDefault,
                         int dx, int dy, boolean right, boolean bottom) {
        super(id, name, description, Category.HUD, defaultEnabled);
        this.dx = dx;
        this.dy = dy;
        this.right = right;
        this.bottom = bottom;
        this.scale = intSetting("scale", "Boyut", 50, 200, 100, v -> v + "%");
        this.background = boolSetting("bg", "Arka plan", backgroundDefault);
    }

    /** Icerigin boyutu {genislik, yukseklik}; sifir veya negatifse gizli. */
    protected abstract int[] size(MinecraftClient mc);

    /** Icerigi (0,0) noktasindan baslayarak ciz. */
    protected abstract void paint(DrawContext ctx, MinecraftClient mc);

    public void resetPosition() {
        FpsBoostConfig.INSTANCE.posX.remove(id);
        FpsBoostConfig.INSTANCE.posY.remove(id);
    }

    public void draw(DrawContext ctx, MinecraftClient mc, boolean editing) {
        int[] sz = size(mc);
        boolean empty = sz[0] <= 0 || sz[1] <= 0;
        if (empty && !editing) {
            return;
        }
        int cw = empty ? mc.textRenderer.getWidth(name) : sz[0];
        int ch = empty ? 9 : sz[1];
        float s = get(scale) / 100f;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int w = Math.round((cw + 4) * s);
        int h = Math.round((ch + 4) * s);

        Integer px = FpsBoostConfig.INSTANCE.posX.get(id);
        Integer py = FpsBoostConfig.INSTANCE.posY.get(id);
        int x = px != null ? px : (right ? sw - w - dx : dx);
        int y = py != null ? py : (bottom ? sh - h - dy : dy);
        x = Math.max(0, Math.min(x, Math.max(0, sw - w)));
        y = Math.max(0, Math.min(y, Math.max(0, sh - h)));
        bx = x;
        by = y;
        bw = w;
        bh = h;

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(x, y, 0.0);
        m.scale(s, s, 1.0f);
        if (getBool(background)) {
            ctx.fill(0, 0, cw + 4, ch + 4, 0x66000000);
        }
        if (editing) {
            int c = 0xFF2EA043;
            ctx.fill(0, 0, cw + 4, 1, c);
            ctx.fill(0, ch + 3, cw + 4, ch + 4, c);
            ctx.fill(0, 0, 1, ch + 4, c);
            ctx.fill(cw + 3, 0, cw + 4, ch + 4, c);
        }
        m.translate(2.0, 2.0, 0.0);
        if (empty) {
            ctx.drawTextWithShadow(mc.textRenderer, name, 0, 0, 0xFF8B949E);
        } else {
            paint(ctx, mc);
        }
        m.pop();
    }
}
