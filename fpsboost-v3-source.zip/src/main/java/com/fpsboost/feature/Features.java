package com.fpsboost.feature;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/** Tum modullerin kaydi. */
public final class Features {
    private Features() {
    }

    // ---------- Performans ----------
    public static final CullFeature PLAYER_CULL = new CullFeature("player_cull", "Oyuncu mesafe sınırı",
            "Uzaktaki oyuncuları çizmez. FPS'e en çok katkı veren ayar.", true, 8, 128, 64, true);
    public static final CullFeature ENTITY_CULL = new CullFeature("entity_cull", "Varlık mesafe sınırı",
            "Uzaktaki mob ve hayvanları çizmez.", false, 16, 128, 64, true);
    public static final CullFeature ITEM_CULL = new CullFeature("item_cull", "Eşya mesafe sınırı",
            "Yerdeki eşyaları uzaktan çizmez.", false, 8, 128, 32, true);
    public static final CullFeature NAMETAG_CULL = new CullFeature("nametag_cull", "İsim etiketi sınırı",
            "Uzaktaki oyuncuların isim etiketini gizler.", true, 8, 64, 24, false);

    // ---------- HUD ----------
    public static final List<HudFeature> HUDS = List.of(
            new HudFeatures.Fps(),
            new HudFeatures.Cps(),
            new HudFeatures.Ping(),
            new HudFeatures.Coords(),
            new HudFeatures.Compass(),
            new HudFeatures.Speed(),
            new HudFeatures.Memory(),
            new HudFeatures.Clock(),
            new HudFeatures.Players(),
            new HudFeatures.Day(),
            new HudFeatures.Potions(),
            new HudFeatures.Keystrokes(),
            new HudFeatures.Armor()
    );

    // ---------- Gorunum ----------
    public static final Zoom ZOOM = new Zoom();
    public static final Fullbright FULLBRIGHT = new Fullbright();
    public static final Feature NO_HURT = new Feature("no_hurt_cam", "Hasar sarsıntısı yok",
            "Hasar alınca ekranın sallanmasını kapatır.", Feature.Category.VISUAL, false) {
    };

    // ---------- Oynanis ----------
    public static final AutoSprint AUTO_SPRINT = new AutoSprint();

    public static final List<Feature> ALL;

    static {
        List<Feature> l = new ArrayList<>();
        l.add(PLAYER_CULL);
        l.add(ENTITY_CULL);
        l.add(ITEM_CULL);
        l.add(NAMETAG_CULL);
        l.addAll(HUDS);
        l.add(ZOOM);
        l.add(FULLBRIGHT);
        l.add(NO_HURT);
        l.add(AUTO_SPRINT);
        ALL = Collections.unmodifiableList(l);
    }

    public static List<Feature> inCategory(Feature.Category c) {
        return ALL.stream().filter(f -> f.category == c).collect(Collectors.toList());
    }

    // ---------- Ozel moduller ----------

    /** Tusa basili tutunca yaklasir. */
    public static final class Zoom extends Feature {
        public final Setting factor;
        public final Setting smooth;
        /** 1.0 = zoom yok. ZoomMixin okur. */
        public volatile double current = 1.0;

        Zoom() {
            super("zoom", "Zoom", "Zoom tuşunu (varsayılan C) basılı tutunca yaklaşır.", Category.VISUAL, true);
            factor = intSetting("factor", "Yakınlaştırma", 2, 10, 4, v -> v + "x");
            smooth = boolSetting("smooth", "Yumuşak geçiş", true);
        }

        public void update(boolean held) {
            double target = (held && isEnabled()) ? get(factor) : 1.0;
            if (getBool(smooth)) {
                current += (target - current) * 0.4;
                if (Math.abs(target - current) < 0.01) {
                    current = target;
                }
            } else {
                current = target;
            }
        }
    }

    /** Gece gorusu efektiyle her yeri aydinlik yapar (sadece sende gorunur). */
    public static final class Fullbright extends Feature {
        Fullbright() {
            super("fullbright", "Gece görüşü", "Karanlıkta her yeri aydınlık gösterir.", Category.VISUAL, false);
        }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null) {
                return;
            }
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            boolean ours = cur != null && cur.getDuration() > 500000;
            if (isEnabled()) {
                if (cur == null) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000000, 0, false, false, false));
                }
            } else if (ours) {
                p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            }
        }
    }

    /** Ileri giderken otomatik kosar. */
    public static final class AutoSprint extends Feature {
        private boolean forced;

        AutoSprint() {
            super("auto_sprint", "Otomatik koşu", "İleri giderken sürekli koşar.", Category.GAMEPLAY, false);
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.player == null) {
                forced = false;
                return;
            }
            KeyBinding sprint = mc.options.sprintKey;
            boolean forward = mc.options.forwardKey.isPressed();
            if (isEnabled() && forward && mc.currentScreen == null && !mc.player.isSneaking()) {
                sprint.setPressed(true);
                forced = true;
            } else if (forced) {
                sprint.setPressed(false);
                forced = false;
            }
        }
    }
}
