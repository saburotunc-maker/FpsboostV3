package com.fpsboost.feature;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** Birkac satir yazidan olusan HUD modulu. */
public abstract class TextHud extends HudFeature {

    /** Sol ustte, dy piksel asagida. */
    protected TextHud(String id, String name, String description, boolean defaultEnabled, int dy) {
        super(id, name, description, defaultEnabled, true, 4, dy, false, false);
    }

    /** Istege bagli konum: sag/alt kenara yapisik. */
    protected TextHud(String id, String name, String description, boolean defaultEnabled,
                      int dx, int dy, boolean right, boolean bottom) {
        super(id, name, description, defaultEnabled, true, dx, dy, right, bottom);
    }

    protected abstract List<String> lines(MinecraftClient mc);

    @Override
    protected int[] size(MinecraftClient mc) {
        List<String> l = lines(mc);
        int w = 0;
        for (String s : l) {
            w = Math.max(w, mc.textRenderer.getWidth(s));
        }
        return new int[]{w, l.size() * 10 - 1};
    }

    @Override
    protected void paint(DrawContext ctx, MinecraftClient mc) {
        int y = 0;
        for (String s : lines(mc)) {
            ctx.drawTextWithShadow(mc.textRenderer, s, 0, y, 0xFFFFFFFF);
            y += 10;
        }
    }
}
