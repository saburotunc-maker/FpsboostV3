package com.fpsboost.feature;

import com.fpsboost.Clicks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Tum HUD modulleri. */
public final class HudFeatures {
    private HudFeatures() {
    }

    public static final class Fps extends TextHud {
        public Fps() {
            super("fps", "FPS göstergesi", "Saniyedeki kare sayısını gösterir.", true, 4);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            return List.of("FPS: " + mc.getCurrentFps());
        }
    }

    public static final class Cps extends TextHud {
        public Cps() {
            super("cps", "CPS sayacı", "Saniyedeki sol | sağ tık sayısı.", true, 16);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            return List.of("CPS: " + Clicks.left() + " | " + Clicks.right());
        }
    }

    public static final class Ping extends TextHud {
        public Ping() {
            super("ping", "Ping göstergesi", "Sunucu gecikmesini (ms) gösterir.", false, 28);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            ClientPlayNetworkHandler nh = mc.getNetworkHandler();
            if (nh == null || mc.player == null) {
                return List.of("Ping: -");
            }
            PlayerListEntry e = nh.getPlayerListEntry(mc.player.getUuid());
            return List.of(e == null ? "Ping: -" : "Ping: " + e.getLatency() + " ms");
        }
    }

    public static final class Coords extends TextHud {
        public Coords() {
            super("coords", "Koordinatlar", "X Y Z konumunu gösterir.", false, 40);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            if (mc.player == null) {
                return List.of();
            }
            return List.of("XYZ: " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
        }
    }

    public static final class Compass extends TextHud {
        public Compass() {
            super("direction", "Yön göstergesi", "Baktığın yönü gösterir.", false, 52);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            if (mc.player == null) {
                return List.of();
            }
            Direction d = mc.player.getHorizontalFacing();
            String n;
            if (d == Direction.NORTH) {
                n = "Kuzey";
            } else if (d == Direction.SOUTH) {
                n = "Güney";
            } else if (d == Direction.EAST) {
                n = "Doğu";
            } else {
                n = "Batı";
            }
            int yaw = Math.round(MathHelper.wrapDegrees(mc.player.getYaw()));
            return List.of("Yön: " + n + " (" + yaw + "°)");
        }
    }

    public static final class Speed extends TextHud {
        private double lastX;
        private double lastZ;
        private boolean hasLast;
        private double speed;

        public Speed() {
            super("speed", "Hız göstergesi", "Yatay hızını blok/saniye olarak gösterir.", false, 64);
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.player == null) {
                hasLast = false;
                return;
            }
            double x = mc.player.getX();
            double z = mc.player.getZ();
            if (hasLast) {
                speed = Math.hypot(x - lastX, z - lastZ) * 20.0;
            }
            lastX = x;
            lastZ = z;
            hasLast = true;
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            return List.of("Hız: " + String.format(Locale.ROOT, "%.1f", speed) + " b/s");
        }
    }

    public static final class Memory extends TextHud {
        public Memory() {
            super("memory", "RAM göstergesi", "Kullanılan / ayrılan belleği gösterir.", false, 76);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) >> 20;
            long max = rt.maxMemory() >> 20;
            return List.of("RAM: " + used + "/" + max + " MB");
        }
    }

    public static final class Clock extends TextHud {
        private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm");

        public Clock() {
            super("clock", "Saat", "Gerçek saati gösterir.", false, 88);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            return List.of("Saat: " + LocalTime.now().format(FMT));
        }
    }

    public static final class Players extends TextHud {
        public Players() {
            super("players", "Oyuncu sayısı", "Çevrendeki yüklü oyuncu sayısı.", false, 100);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            if (mc.world == null) {
                return List.of();
            }
            return List.of("Oyuncu: " + mc.world.getPlayers().size());
        }
    }

    public static final class Day extends TextHud {
        public Day() {
            super("day", "Gün sayacı", "Dünyada kaçıncı günde olduğunu gösterir.", false, 112);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            if (mc.world == null) {
                return List.of();
            }
            return List.of("Gün: " + (mc.world.getTimeOfDay() / 24000L + 1));
        }
    }

    public static final class Potions extends TextHud {
        public Potions() {
            super("potions", "İksir etkileri", "Aktif iksir etkilerini ve süresini listeler.", false, 4, 4, true, false);
        }

        @Override
        protected List<String> lines(MinecraftClient mc) {
            List<String> out = new ArrayList<>();
            if (mc.player == null) {
                return out;
            }
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                if (e.getDuration() > 500000) {
                    continue; // gece gorusu modulunun kendi efekti
                }
                String n = Text.translatable(e.getTranslationKey()).getString();
                int lvl = e.getAmplifier() + 1;
                String t;
                if (e.getDuration() < 0) {
                    t = "sonsuz";
                } else {
                    int sec = e.getDuration() / 20;
                    t = (sec / 60) + ":" + String.format(Locale.ROOT, "%02d", sec % 60);
                }
                out.add(n + (lvl > 1 ? " " + lvl : "") + "  " + t);
            }
            return out;
        }
    }

    public static final class Keystrokes extends HudFeature {
        public Keystrokes() {
            super("keystrokes", "Tuş göstergesi", "W A S D, fare ve boşluk tuşlarını gösterir.", false, false, 4, 4, false, true);
        }

        @Override
        protected int[] size(MinecraftClient mc) {
            return new int[]{64, 80};
        }

        private void key(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean down) {
            ctx.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x66000000);
            ctx.drawCenteredTextWithShadow(mc.textRenderer, label, x + w / 2, y + (h - 8) / 2,
                    down ? 0xFF000000 : 0xFFFFFFFF);
        }

        @Override
        protected void paint(DrawContext ctx, MinecraftClient mc) {
            key(ctx, mc, 22, 0, 20, 20, "W", mc.options.forwardKey.isPressed());
            key(ctx, mc, 0, 22, 20, 20, "A", mc.options.leftKey.isPressed());
            key(ctx, mc, 22, 22, 20, 20, "S", mc.options.backKey.isPressed());
            key(ctx, mc, 44, 22, 20, 20, "D", mc.options.rightKey.isPressed());
            key(ctx, mc, 0, 44, 31, 20, "SOL", mc.options.attackKey.isPressed());
            key(ctx, mc, 33, 44, 31, 20, "SAĞ", mc.options.useKey.isPressed());
            boolean jump = mc.options.jumpKey.isPressed();
            ctx.fill(0, 66, 64, 78, jump ? 0xAAFFFFFF : 0x66000000);
            ctx.fill(16, 71, 48, 73, jump ? 0xFF000000 : 0xFFFFFFFF);
        }
    }

    public static final class Armor extends HudFeature {
        private static final EquipmentSlot[] SLOTS = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND
        };

        public Armor() {
            super("armor", "Zırh göstergesi", "Zırh ve eldeki eşyanın dayanıklılığını gösterir.", true, false, 4, 60, true, true);
        }

        private List<ItemStack> stacks(MinecraftClient mc) {
            List<ItemStack> l = new ArrayList<>();
            if (mc.player == null) {
                return l;
            }
            for (EquipmentSlot s : SLOTS) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (!st.isEmpty()) {
                    l.add(st);
                }
            }
            return l;
        }

        @Override
        protected int[] size(MinecraftClient mc) {
            int n = stacks(mc).size();
            return new int[]{n == 0 ? 0 : 44, n * 18 - 2};
        }

        @Override
        protected void paint(DrawContext ctx, MinecraftClient mc) {
            int y = 0;
            for (ItemStack st : stacks(mc)) {
                ctx.drawItem(st, 0, y);
                String text = "";
                int color = 0xFFFFFFFF;
                if (st.isDamageable()) {
                    int left = st.getMaxDamage() - st.getDamage();
                    text = String.valueOf(left);
                    float ratio = left / (float) st.getMaxDamage();
                    color = ratio > 0.5f ? 0xFF55FF55 : (ratio > 0.2f ? 0xFFFFFF55 : 0xFFFF5555);
                } else if (st.getCount() > 1) {
                    text = "x" + st.getCount();
                }
                ctx.drawTextWithShadow(mc.textRenderer, text, 19, y + 4, color);
                y += 18;
            }
        }
    }
}
