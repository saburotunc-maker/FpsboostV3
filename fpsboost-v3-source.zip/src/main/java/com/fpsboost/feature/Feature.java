package com.fpsboost.feature;

import com.fpsboost.FpsBoostConfig;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntFunction;

/** Bir modul: GUI'den acilip kapanir, kendi ayarlari olabilir. */
public abstract class Feature {

    public enum Category {
        PERFORMANCE("Performans"),
        HUD("HUD"),
        VISUAL("Görünüm"),
        GAMEPLAY("Oynanış");

        public final String label;

        Category(String label) {
            this.label = label;
        }
    }

    /** Tam sayi ayari (kaydirici) veya ac/kapa ayari (min 0, max 1). */
    public static final class Setting {
        public final String key;
        public final String name;
        public final int min;
        public final int max;
        public final int def;
        public final boolean bool;
        public final IntFunction<String> fmt;

        Setting(String key, String name, int min, int max, int def, boolean bool, IntFunction<String> fmt) {
            this.key = key;
            this.name = name;
            this.min = min;
            this.max = max;
            this.def = def;
            this.bool = bool;
            this.fmt = fmt;
        }
    }

    public final String id;
    public final String name;
    public final String description;
    public final Category category;
    private final boolean defaultEnabled;
    public final List<Setting> settings = new ArrayList<>();

    protected Feature(String id, String name, String description, Category category, boolean defaultEnabled) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.defaultEnabled = defaultEnabled;
    }

    public boolean isEnabled() {
        Boolean b = FpsBoostConfig.INSTANCE.enabled.get(id);
        return b != null ? b : defaultEnabled;
    }

    public void setEnabled(boolean v) {
        FpsBoostConfig.INSTANCE.enabled.put(id, v);
    }

    public void toggle() {
        setEnabled(!isEnabled());
    }

    protected Setting intSetting(String key, String name, int min, int max, int def, IntFunction<String> fmt) {
        Setting s = new Setting(key, name, min, max, def, false, fmt);
        settings.add(s);
        return s;
    }

    protected Setting boolSetting(String key, String name, boolean def) {
        Setting s = new Setting(key, name, 0, 1, def ? 1 : 0, true, v -> v == 1 ? "AÇIK" : "KAPALI");
        settings.add(s);
        return s;
    }

    public int get(Setting s) {
        Integer v = FpsBoostConfig.INSTANCE.values.get(id + "." + s.key);
        int r = v != null ? v : s.def;
        return Math.max(s.min, Math.min(s.max, r));
    }

    public boolean getBool(Setting s) {
        return get(s) == 1;
    }

    public void set(Setting s, int v) {
        FpsBoostConfig.INSTANCE.values.put(id + "." + s.key, Math.max(s.min, Math.min(s.max, v)));
    }

    /** Her oyun tikinde (saniyede 20 kez) cagrilir. */
    public void onTick(MinecraftClient mc) {
    }
}
