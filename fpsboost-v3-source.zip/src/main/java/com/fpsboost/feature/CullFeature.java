package com.fpsboost.feature;

/** Belirli mesafeden uzaktaki seyleri cizmeyen performans modulu. */
public class CullFeature extends Feature {
    public final Setting dist;
    private final int max;
    private final boolean unlimitedAtMax;

    public CullFeature(String id, String name, String description, boolean defaultEnabled,
                       int min, int max, int defDist, boolean unlimitedAtMax) {
        super(id, name, description, Category.PERFORMANCE, defaultEnabled);
        this.max = max;
        this.unlimitedAtMax = unlimitedAtMax;
        this.dist = intSetting("dist", "Mesafe", min, max, defDist,
                v -> (unlimitedAtMax && v >= max) ? "Sınırsız" : v + " blok");
    }

    /** Verilen kare mesafe sinirdan uzak mi (modul aciksa). */
    public boolean tooFar(double distSq) {
        if (!isEnabled()) {
            return false;
        }
        int limit = get(dist);
        if (unlimitedAtMax && limit >= max) {
            return false;
        }
        return distSq > (double) limit * limit;
    }
}
