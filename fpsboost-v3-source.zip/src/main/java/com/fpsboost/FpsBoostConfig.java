package com.fpsboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Tum ayarlar tek JSON dosyasinda: config/fpsboost-modules.json */
public class FpsBoostConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fpsboost-modules.json");

    public static FpsBoostConfig INSTANCE = new FpsBoostConfig();

    /** modul id -> acik mi (yoksa modulun varsayilani) */
    public Map<String, Boolean> enabled = new HashMap<>();
    /** "modulId.ayarAnahtari" -> deger */
    public Map<String, Integer> values = new HashMap<>();
    /** HUD modullerinin ekran konumu (piksel); yoksa varsayilan konum */
    public Map<String, Integer> posX = new HashMap<>();
    public Map<String, Integer> posY = new HashMap<>();

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                FpsBoostConfig loaded = GSON.fromJson(Files.readString(FILE), FpsBoostConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                }
            }
        } catch (Exception e) {
            System.err.println("[FPS Boost] Ayar dosyasi okunamadi, varsayilanlar kullaniliyor: " + e);
        }
        FpsBoostConfig c = INSTANCE;
        if (c.enabled == null) c.enabled = new HashMap<>();
        if (c.values == null) c.values = new HashMap<>();
        if (c.posX == null) c.posX = new HashMap<>();
        if (c.posY == null) c.posY = new HashMap<>();
        save();
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (IOException e) {
            System.err.println("[FPS Boost] Ayar dosyasi yazilamadi: " + e);
        }
    }

    public static void reset() {
        INSTANCE = new FpsBoostConfig();
        save();
    }
}
