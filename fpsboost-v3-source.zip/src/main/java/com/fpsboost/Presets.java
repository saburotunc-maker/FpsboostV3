package com.fpsboost;

import com.fpsboost.feature.CullFeature;
import com.fpsboost.feature.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Hazir ayarlar: oyunun kendi secenekleri + modun mesafe sinirlari. */
public final class Presets {
    public static final String[] NAMES = {"Maks FPS", "Dengeli", "Güzel"};

    private Presets() {
    }

    private static void cull(CullFeature f, boolean on, int d) {
        f.setEnabled(on);
        f.set(f.dist, d);
    }

    public static void apply(int index) {
        GameOptions o = MinecraftClient.getInstance().options;

        switch (index) {
            case 0: // Maks FPS
                o.getViewDistance().setValue(8);
                o.getSimulationDistance().setValue(6);
                o.getMaxFps().setValue(260);
                o.getParticles().setValue(ParticlesMode.MINIMAL);
                o.getGraphicsMode().setValue(GraphicsMode.FAST);
                o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
                o.getEntityShadows().setValue(false);
                o.getEntityDistanceScaling().setValue(0.5);
                o.getBiomeBlendRadius().setValue(0);
                o.getMipmapLevels().setValue(0);
                o.getBobView().setValue(false);
                cull(Features.PLAYER_CULL, true, 32);
                cull(Features.ENTITY_CULL, true, 48);
                cull(Features.ITEM_CULL, true, 24);
                cull(Features.NAMETAG_CULL, true, 16);
                break;
            case 1: // Dengeli
                o.getViewDistance().setValue(12);
                o.getSimulationDistance().setValue(8);
                o.getMaxFps().setValue(144);
                o.getParticles().setValue(ParticlesMode.DECREASED);
                o.getGraphicsMode().setValue(GraphicsMode.FANCY);
                o.getCloudRenderMode().setValue(CloudRenderMode.FAST);
                o.getEntityShadows().setValue(true);
                o.getEntityDistanceScaling().setValue(1.0);
                o.getBiomeBlendRadius().setValue(2);
                o.getMipmapLevels().setValue(2);
                o.getBobView().setValue(true);
                cull(Features.PLAYER_CULL, true, 64);
                cull(Features.ENTITY_CULL, false, 96);
                cull(Features.ITEM_CULL, false, 48);
                cull(Features.NAMETAG_CULL, true, 24);
                break;
            default: // Güzel
                o.getViewDistance().setValue(16);
                o.getSimulationDistance().setValue(12);
                o.getMaxFps().setValue(144);
                o.getParticles().setValue(ParticlesMode.ALL);
                o.getGraphicsMode().setValue(GraphicsMode.FANCY);
                o.getCloudRenderMode().setValue(CloudRenderMode.FANCY);
                o.getEntityShadows().setValue(true);
                o.getEntityDistanceScaling().setValue(1.0);
                o.getBiomeBlendRadius().setValue(4);
                o.getMipmapLevels().setValue(4);
                o.getBobView().setValue(true);
                cull(Features.PLAYER_CULL, false, 128);
                cull(Features.ENTITY_CULL, false, 128);
                cull(Features.ITEM_CULL, false, 128);
                cull(Features.NAMETAG_CULL, false, 64);
                break;
        }
        FpsBoostConfig.save();
        o.write();
    }
}
