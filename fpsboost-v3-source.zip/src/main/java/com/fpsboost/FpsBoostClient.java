package com.fpsboost;

import com.fpsboost.feature.Feature;
import com.fpsboost.feature.Features;
import com.fpsboost.feature.HudFeature;
import com.fpsboost.gui.HudEditorScreen;
import com.fpsboost.gui.ModMenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashMap;
import java.util.Map;

public class FpsBoostClient implements ClientModInitializer {
    private static final String CATEGORY = "category.fpsboost";

    private static KeyBinding openMenu;
    private static KeyBinding zoomKey;
    private static final Map<KeyBinding, Feature> TOGGLE_KEYS = new LinkedHashMap<>();

    private static KeyBinding bind(String translationKey, int key) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding(translationKey, InputUtil.Type.KEYSYM, key, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        FpsBoostConfig.load();

        // Bu tuslar oyunda Ayarlar > Kontroller > FPS Boost altinda gorunur ve degistirilebilir.
        openMenu = bind("key.fpsboost.open", GLFW.GLFW_KEY_RIGHT_SHIFT);
        zoomKey = bind("key.fpsboost.zoom", GLFW.GLFW_KEY_C);
        // Her modul icin bos bir ac/kapat tusu
        for (Feature f : Features.ALL) {
            TOGGLE_KEYS.put(bind("key.fpsboost.toggle." + f.id, GLFW.GLFW_KEY_UNKNOWN), f);
        }

        ClientTickEvents.END_CLIENT_TICK.register(FpsBoostClient::onTick);
        HudRenderCallback.EVENT.register((ctx, tick) -> onHud(ctx));
    }

    private static void msg(MinecraftClient client, String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal("FPS Boost · " + text), true);
        }
    }

    private static void onTick(MinecraftClient client) {
        while (openMenu.wasPressed()) {
            client.setScreen(new ModMenuScreen(client.currentScreen));
        }
        for (Map.Entry<KeyBinding, Feature> e : TOGGLE_KEYS.entrySet()) {
            while (e.getKey().wasPressed()) {
                Feature f = e.getValue();
                f.toggle();
                FpsBoostConfig.save();
                msg(client, f.name + ": " + (f.isEnabled() ? "AÇIK" : "KAPALI"));
            }
        }

        Features.ZOOM.update(zoomKey.isPressed() && client.currentScreen == null);

        for (Feature f : Features.ALL) {
            f.onTick(client);
        }
    }

    private static void onHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) {
            return;
        }
        if (mc.currentScreen == null) {
            Clicks.sample(mc);
        }
        if (mc.options.hudHidden || mc.currentScreen instanceof HudEditorScreen) {
            return;
        }
        for (HudFeature h : Features.HUDS) {
            if (h.isEnabled()) {
                h.draw(ctx, mc, false);
            }
        }
    }
}
