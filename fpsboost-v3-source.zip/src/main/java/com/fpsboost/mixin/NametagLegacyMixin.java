package com.fpsboost.mixin;

import com.fpsboost.feature.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Eski surumler (1.20.x - 1.21.1): hasLabel(entity).
 * Yeni surumlerde imza uymaz, mixin kendiliginden atlanir (NametagModernMixin devreye girer).
 */
@Mixin(LivingEntityRenderer.class)
public class NametagLegacyMixin {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
    private void fpsboost$hideFarNametags(LivingEntity entity, CallbackInfoReturnable<Boolean> cir) {
        if (!Features.NAMETAG_CULL.isEnabled() || !(entity instanceof PlayerEntity)) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (entity == client.player || client.getCameraEntity() == null) {
            return;
        }
        if (Features.NAMETAG_CULL.tooFar(client.getCameraEntity().squaredDistanceTo(entity))) {
            cir.setReturnValue(false);
        }
    }
}
