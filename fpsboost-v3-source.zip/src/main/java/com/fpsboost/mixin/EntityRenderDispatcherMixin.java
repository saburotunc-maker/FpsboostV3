package com.fpsboost.mixin;

import com.fpsboost.feature.CullFeature;
import com.fpsboost.feature.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {

    /**
     * Uzaktaki oyuncu / esya / diger varliklari hic cizme.
     * Kendimizi, kamerayi ve bindigimiz araci asla gizlemeyiz.
     * (1.20.1 - 1.21.4 hepsinde ayni imza.)
     */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void fpsboost$cull(Entity entity, Frustum frustum, double x, double y, double z,
                               CallbackInfoReturnable<Boolean> cir) {
        CullFeature c;
        if (entity instanceof PlayerEntity) {
            c = Features.PLAYER_CULL;
        } else if (entity instanceof ItemEntity) {
            c = Features.ITEM_CULL;
        } else {
            c = Features.ENTITY_CULL;
        }
        if (!c.isEnabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (entity == client.player || entity == client.getCameraEntity()
                || (client.player != null && entity == client.player.getVehicle())) {
            return;
        }
        if (c.tooFar(entity.squaredDistanceTo(x, y, z))) {
            cir.setReturnValue(false);
        }
    }
}
