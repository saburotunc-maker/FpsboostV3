package com.fpsboost.mixin;

import com.fpsboost.feature.Features;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class ZoomMixin {

    /** Zoom: gorus acisini zoom carpanina boler (vanilla FOV sinirini asar). */
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void fpsboost$zoom(Camera camera, float tickDelta, boolean changingFov,
                               CallbackInfoReturnable<Double> cir) {
        double zoom = Features.ZOOM.current;
        if (zoom > 1.001) {
            cir.setReturnValue(cir.getReturnValueD() / zoom);
        }
    }
}
