package com.fpsboost.mixin;

import com.fpsboost.feature.Features;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Yeni surumler (1.21.2+): hasLabel(entity, kareMesafe).
 * Eski surumlerde imza uymaz, mixin kendiliginden atlanir.
 */
@Mixin(LivingEntityRenderer.class)
public class NametagModernMixin {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
    private void fpsboost$hideFarNametags(LivingEntity entity, double squaredDistanceToCamera,
                                          CallbackInfoReturnable<Boolean> cir) {
        if (!Features.NAMETAG_CULL.isEnabled() || !(entity instanceof PlayerEntity)) {
            return;
        }
        if (entity == MinecraftClient.getInstance().player) {
            return;
        }
        if (Features.NAMETAG_CULL.tooFar(squaredDistanceToCamera)) {
            cir.setReturnValue(false);
        }
    }
}
