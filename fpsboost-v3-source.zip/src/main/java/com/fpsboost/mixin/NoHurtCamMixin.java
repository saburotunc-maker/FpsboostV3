package com.fpsboost.mixin;

import com.fpsboost.feature.Features;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class NoHurtCamMixin {

    /** Hasar alinca ekranin sallanmasini iptal eder. */
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void fpsboost$noHurt(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Features.NO_HURT.isEnabled()) {
            ci.cancel();
        }
    }
}
