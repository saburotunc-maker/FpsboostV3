package com.fpsboost.gui;

import com.fpsboost.FpsBoostConfig;
import com.fpsboost.Presets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.text.Text;

/** Hazir ayarlar + oyunun kendi performans/gorunum ayarlari. */
public class VideoScreen extends Screen {
    private static final ParticlesMode[] PARTICLES = {ParticlesMode.ALL, ParticlesMode.DECREASED, ParticlesMode.MINIMAL};
    private static final String[] PARTICLE_LABELS = {"Hepsi", "Az", "Minimum"};
    private static final GraphicsMode[] GRAPHICS = {GraphicsMode.FAST, GraphicsMode.FANCY, GraphicsMode.FABULOUS};
    private static final String[] GRAPHICS_LABELS = {"Hızlı", "Süslü", "Muhteşem"};
    private static final CloudRenderMode[] CLOUDS = {CloudRenderMode.OFF, CloudRenderMode.FAST, CloudRenderMode.FANCY};
    private static final String[] CLOUD_LABELS = {"Kapalı", "Hızlı", "Süslü"};

    private final Screen parent;
    private String status = "";

    public VideoScreen(Screen parent) {
        super(Text.literal("Hazır ve oyun ayarları"));
        this.parent = parent;
    }

    private static <T> int idx(T[] arr, T v) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == v) {
                return i;
            }
        }
        return 0;
    }

    @Override
    protected void init() {
        GameOptions o = MinecraftClient.getInstance().options;
        int pw = Math.min(this.width - 10, 380);
        int px = (this.width - pw) / 2;
        int cw = (pw - 10) / 2;

        // hazir ayarlar
        int pbw = (pw - 8) / 3;
        for (int i = 0; i < Presets.NAMES.length; i++) {
            final int idx = i;
            this.addDrawableChild(Ui.button(px + i * (pbw + 4), 26, pbw, Presets.NAMES[i], () -> {
                Presets.apply(idx);
                status = "Uygulandı: " + Presets.NAMES[idx];
                this.clearChildren();
                this.init();
            }));
        }

        int top = 64;
        int[] col = {px, px + cw + 10};
        this.addDrawableChild(new Ui.IntSlider(col[0], top, cw, "Render", 2, 32, o.getViewDistance().getValue(),
                v -> v + " chunk", v -> o.getViewDistance().setValue(v), true));
        this.addDrawableChild(new Ui.IntSlider(col[1], top, cw, "Simülasyon", 5, 32, o.getSimulationDistance().getValue(),
                v -> v + " chunk", v -> o.getSimulationDistance().setValue(v), true));
        this.addDrawableChild(new Ui.IntSlider(col[0], top + 24, cw, "Maks FPS", 30, 260, o.getMaxFps().getValue(),
                v -> v >= 260 ? "Sınırsız" : String.valueOf(v), v -> o.getMaxFps().setValue(v), false));
        this.addDrawableChild(new Ui.IntSlider(col[1], top + 24, cw, "FOV", 30, 110, o.getFov().getValue(),
                String::valueOf, v -> o.getFov().setValue(v), false));
        this.addDrawableChild(Ui.cycler(col[0], top + 48, cw, "Partikül", PARTICLE_LABELS,
                () -> idx(PARTICLES, o.getParticles().getValue()), i -> o.getParticles().setValue(PARTICLES[i])));
        this.addDrawableChild(Ui.cycler(col[1], top + 48, cw, "Grafik", GRAPHICS_LABELS,
                () -> idx(GRAPHICS, o.getGraphicsMode().getValue()), i -> o.getGraphicsMode().setValue(GRAPHICS[i])));
        this.addDrawableChild(Ui.cycler(col[0], top + 72, cw, "Bulut", CLOUD_LABELS,
                () -> idx(CLOUDS, o.getCloudRenderMode().getValue()), i -> o.getCloudRenderMode().setValue(CLOUDS[i])));
        this.addDrawableChild(Ui.toggle(col[1], top + 72, cw, "Gölge",
                () -> o.getEntityShadows().getValue(), v -> o.getEntityShadows().setValue(v)));
        this.addDrawableChild(new Ui.IntSlider(col[0], top + 96, cw, "Biyom geçişi", 0, 7, o.getBiomeBlendRadius().getValue(),
                String::valueOf, v -> o.getBiomeBlendRadius().setValue(v), true));
        this.addDrawableChild(Ui.toggle(col[1], top + 96, cw, "Kafa sallanma",
                () -> o.getBobView().getValue(), v -> o.getBobView().setValue(v)));

        this.addDrawableChild(Ui.button(this.width / 2 - 60, this.height - 26, 120, "Geri", this::close));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x66000000);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "HAZIR VE OYUN AYARLARI", this.width / 2, 9, 0xFFFFFFFF);
        if (!status.isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, status, this.width / 2, 50, 0xFF55FF55);
        }
    }

    @Override
    public void close() {
        FpsBoostConfig.save();
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.options.write();
        mc.setScreen(this.parent);
    }
}
