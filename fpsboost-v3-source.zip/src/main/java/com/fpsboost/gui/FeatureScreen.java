package com.fpsboost.gui;

import com.fpsboost.FpsBoostConfig;
import com.fpsboost.feature.Feature;
import com.fpsboost.feature.HudFeature;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Tek bir modulun ayarlari. */
public class FeatureScreen extends Screen {
    private final Screen parent;
    private final Feature feature;

    public FeatureScreen(Screen parent, Feature feature) {
        super(Text.literal(feature.name));
        this.parent = parent;
        this.feature = feature;
    }

    @Override
    protected void init() {
        int w = Math.min(this.width - 20, 260);
        int x = (this.width - w) / 2;
        int y = 40;
        final Feature f = feature;

        this.addDrawableChild(Ui.toggle(x, y, w, "Aktif", f::isEnabled, f::setEnabled));
        y += 24;

        for (final Feature.Setting s : f.settings) {
            if (s.bool) {
                this.addDrawableChild(Ui.toggle(x, y, w, s.name, () -> f.getBool(s), v -> f.set(s, v ? 1 : 0)));
            } else {
                this.addDrawableChild(new Ui.IntSlider(x, y, w, s.name, s.min, s.max, f.get(s),
                        s.fmt, v -> f.set(s, v), false));
            }
            y += 24;
        }

        if (f instanceof HudFeature) {
            final HudFeature h = (HudFeature) f;
            this.addDrawableChild(Ui.button(x, y, w, "Konumu sıfırla", h::resetPosition));
        }

        this.addDrawableChild(Ui.button(this.width / 2 - 60, this.height - 26, 120, "Geri", this::close));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x66000000);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, feature.name, this.width / 2, 9, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, feature.description, this.width / 2, 24, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        FpsBoostConfig.save();
        this.client.setScreen(this.parent);
    }
}
