package com.fpsboost.gui;

import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

/** Ortak GUI parcalari. */
public final class Ui {
    private Ui() {
    }

    public static Text onOff(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "AÇIK" : "KAPALI").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    public static ButtonWidget button(int x, int y, int w, String label, Runnable action) {
        return ButtonWidget.builder(Text.literal(label), b -> action.run()).dimensions(x, y, w, 20).build();
    }

    public static ButtonWidget toggle(int x, int y, int w, String name, BooleanSupplier get, Consumer<Boolean> set) {
        return ButtonWidget.builder(onOff(name, get.getAsBoolean()), b -> {
            boolean next = !get.getAsBoolean();
            set.accept(next);
            b.setMessage(onOff(name, next));
        }).dimensions(x, y, w, 20).build();
    }

    public static ButtonWidget cycler(int x, int y, int w, String name, String[] labels, IntSupplier get, IntConsumer set) {
        return ButtonWidget.builder(Text.literal(name + ": " + labels[get.getAsInt()]), b -> {
            int next = (get.getAsInt() + 1) % labels.length;
            set.accept(next);
            b.setMessage(Text.literal(name + ": " + labels[next]));
        }).dimensions(x, y, w, 20).build();
    }

    public static class IntSlider extends SliderWidget {
        private final String name;
        private final int min;
        private final int max;
        private final IntFunction<String> fmt;
        private final IntConsumer setter;
        private final boolean applyOnRelease;

        public IntSlider(int x, int y, int w, String name, int min, int max, int current,
                         IntFunction<String> fmt, IntConsumer setter, boolean applyOnRelease) {
            super(x, y, w, 20, Text.empty(),
                    (Math.max(min, Math.min(max, current)) - min) / (double) (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.setter = setter;
            this.applyOnRelease = applyOnRelease;
            this.updateMessage();
        }

        private int val() {
            return this.min + (int) Math.round(this.value * (this.max - this.min));
        }

        @Override
        protected void updateMessage() {
            if (this.fmt == null) {
                return;
            }
            this.setMessage(Text.literal(this.name + ": " + this.fmt.apply(val())));
        }

        @Override
        protected void applyValue() {
            if (!this.applyOnRelease) {
                this.setter.accept(val());
            }
        }

        @Override
        public void onRelease(double mouseX, double mouseY) {
            super.onRelease(mouseX, mouseY);
            if (this.applyOnRelease) {
                this.setter.accept(val());
            }
        }
    }
}
