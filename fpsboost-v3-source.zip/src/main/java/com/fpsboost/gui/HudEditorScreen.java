package com.fpsboost.gui;

import com.fpsboost.FpsBoostConfig;
import com.fpsboost.feature.Features;
import com.fpsboost.feature.HudFeature;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/** HUD modullerini surukleyerek yerlestirme ekrani. */
public class HudEditorScreen extends Screen {
    private final Screen parent;
    private HudFeature dragging;
    private int offX;
    private int offY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD düzenle"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.addDrawableChild(Ui.button(this.width / 2 - 60, this.height - 26, 120, "Bitti", this::close));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x66000000);
        super.render(ctx, mouseX, mouseY, delta);
        for (HudFeature h : Features.HUDS) {
            if (h.isEnabled()) {
                h.draw(ctx, this.client, true);
            }
        }
        ctx.drawCenteredTextWithShadow(this.textRenderer, "Modülleri sürükleyerek taşı", this.width / 2, 9, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                "Boyut ve arka plan için: Menü > modülün Ayar düğmesi", this.width / 2, 22, 0xFFAAAAAA);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (button == 0) {
            List<HudFeature> l = Features.HUDS;
            for (int i = l.size() - 1; i >= 0; i--) {
                HudFeature h = l.get(i);
                if (h.isEnabled() && mouseX >= h.bx && mouseX <= h.bx + h.bw && mouseY >= h.by && mouseY <= h.by + h.bh) {
                    dragging = h;
                    offX = (int) mouseX - h.bx;
                    offY = (int) mouseY - h.by;
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null) {
            FpsBoostConfig.INSTANCE.posX.put(dragging.id, (int) mouseX - offX);
            FpsBoostConfig.INSTANCE.posY.put(dragging.id, (int) mouseY - offY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragging != null) {
            dragging = null;
            FpsBoostConfig.save();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        FpsBoostConfig.save();
        this.client.setScreen(this.parent);
    }
}
