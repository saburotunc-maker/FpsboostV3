package com.fpsboost.gui;

import com.fpsboost.FpsBoostConfig;
import com.fpsboost.feature.Feature;
import com.fpsboost.feature.Features;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Ana mod menusu: kategorilere ayrilmis modul listesi. */
public class ModMenuScreen extends Screen {
    private static int tab = 0;
    private static int page = 0;

    private final Screen parent;
    private int px;
    private int pw;
    private int cw;
    private int pages = 1;
    private boolean confirmReset = false;

    public ModMenuScreen(Screen parent) {
        super(Text.literal("FPS Boost"));
        this.parent = parent;
    }

    private void rebuild() {
        this.clearChildren();
        this.init();
    }

    private static Text label(Feature f) {
        return Text.literal((f.isEnabled() ? "● " : "○ ") + f.name)
                .formatted(f.isEnabled() ? Formatting.GREEN : Formatting.GRAY);
    }

    @Override
    protected void init() {
        pw = Math.min(this.width - 10, 430);
        px = (this.width - pw) / 2;
        cw = (pw - 10) / 2;

        Feature.Category[] cats = Feature.Category.values();
        int tabs = cats.length + 1;
        int tw = pw / tabs;
        for (int t = 0; t < tabs; t++) {
            final int ti = t;
            String text = t < cats.length ? cats[t].label : "Araçlar";
            ButtonWidget b = ButtonWidget.builder(Text.literal(text), btn -> {
                tab = ti;
                page = 0;
                confirmReset = false;
                rebuild();
            }).dimensions(px + t * tw, 24, tw - 2, 20).build();
            b.active = t != tab;
            this.addDrawableChild(b);
        }

        int top = 50;
        int footerY = this.height - 26;

        if (tab < cats.length) {
            List<Feature> list = Features.inCategory(cats[tab]);
            int rows = Math.max(1, (footerY - top - 4) / 24);
            int perPage = rows * 2;
            pages = Math.max(1, (list.size() + perPage - 1) / perPage);
            if (page >= pages) {
                page = pages - 1;
            }
            for (int i = 0; i < perPage; i++) {
                int idx = page * perPage + i;
                if (idx >= list.size()) {
                    break;
                }
                final Feature f = list.get(idx);
                int x = px + (i % 2) * (cw + 10);
                int y = top + (i / 2) * 24;
                boolean hasCfg = !f.settings.isEmpty();
                int bw = hasCfg ? cw - 38 : cw;
                ButtonWidget fb = ButtonWidget.builder(label(f), b -> {
                    f.toggle();
                    FpsBoostConfig.save();
                    b.setMessage(label(f));
                }).dimensions(x, y, bw, 20).tooltip(Tooltip.of(Text.literal(f.description))).build();
                this.addDrawableChild(fb);
                if (hasCfg) {
                    this.addDrawableChild(Ui.button(x + bw + 2, y, 36, "Ayar",
                            () -> this.client.setScreen(new FeatureScreen(this, f))));
                }
            }
            if (pages > 1) {
                this.addDrawableChild(Ui.button(px, footerY, 20, "<", () -> {
                    page = (page + pages - 1) % pages;
                    rebuild();
                }));
                this.addDrawableChild(Ui.button(px + 22, footerY, 20, ">", () -> {
                    page = (page + 1) % pages;
                    rebuild();
                }));
            }
        } else {
            int w = Math.min(pw, 300);
            int x = (this.width - w) / 2;
            this.addDrawableChild(Ui.button(x, top, w, "Hazır ayarlar ve oyun ayarları",
                    () -> this.client.setScreen(new VideoScreen(this))));
            this.addDrawableChild(Ui.button(x, top + 24, w, "HUD yerlerini düzenle (sürükle)",
                    () -> this.client.setScreen(new HudEditorScreen(this))));
            this.addDrawableChild(Ui.button(x, top + 48, w,
                    confirmReset ? "Emin misin? Tekrar bas: her şey sıfırlanır" : "Tüm mod ayarlarını sıfırla",
                    () -> {
                        if (confirmReset) {
                            FpsBoostConfig.reset();
                            confirmReset = false;
                        } else {
                            confirmReset = true;
                        }
                        rebuild();
                    }));
        }

        this.addDrawableChild(Ui.button(this.width / 2 - 60, footerY, 120, "Bitti", this::close));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x66000000);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "FPS BOOST", this.width / 2, 9, 0xFFFFFFFF);
        if (tab < Feature.Category.values().length) {
            if (pages > 1) {
                ctx.drawTextWithShadow(this.textRenderer, (page + 1) + "/" + pages, px + 48, this.height - 20, 0xFFAAAAAA);
            }
        } else {
            int y = 50 + 80;
            ctx.drawCenteredTextWithShadow(this.textRenderer, "Tuş atamak: Ayarlar > Kontroller > FPS Boost",
                    this.width / 2, y, 0xFFAAAAAA);
            ctx.drawCenteredTextWithShadow(this.textRenderer, "Menü tuşu: Sağ Shift   Zoom: C (basılı tut)",
                    this.width / 2, y + 12, 0xFFAAAAAA);
        }
    }

    @Override
    public void close() {
        FpsBoostConfig.save();
        this.client.setScreen(this.parent);
    }
}
